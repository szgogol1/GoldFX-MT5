# GoldFX 日内订单流（独立包）

黄金/外汇日内订单流 EA：Tick Delta / CVD / VWAP·POC·VA + 可选 DOM。

## 安装

1. 把 `Experts/GoldFX_OrderFlow/` 复制到 MT5 的 `MQL5/Experts/GoldFX_OrderFlow/`
2. 把 `Include/GoldFX/` 复制到 MT5 的 `MQL5/Include/GoldFX/`
3. 把 `Presets/` 里的 .set 文件复制到 MT5 的 `MQL5/Presets/`
4. MetaEditor 打开 `GoldFX_OrderFlow.mq5`，F7 编译

## 使用

- 挂 XAUUSD M5（外汇换品种即可），Magic 默认 20260903
- 加载 `GoldFX_OrderFlow_XAUUSD_M5.set`（或先用 Conservative 预设观察）
- 策略测试器选 **Every tick based on real ticks**
- 建议先 `InpAllowTrade=false` 观察 CVD/VWAP 画线
