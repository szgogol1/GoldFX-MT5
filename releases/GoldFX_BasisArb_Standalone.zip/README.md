# GoldFX 基差套利（独立包）

黄金现货–期货基差 Z 分均值回归套利（双边对冲）。

## 安装

1. 把 `Experts/GoldFX_BasisArb/` 复制到 MT5 的 `MQL5/Experts/GoldFX_BasisArb/`
2. 把 `Include/GoldFX/` 复制到 MT5 的 `MQL5/Include/GoldFX/`
3. 把 `Presets/` 里的 .set 文件复制到 MT5 的 `MQL5/Presets/`
4. MetaEditor 打开 `GoldFX_BasisArb.mq5`，F7 编译

## 使用

- 确认账户为**对冲模式**
- 挂 XAUUSD 图表，设置 `InpFutSymbol` 为你的期货代码
- 加载 `GoldFX_BasisArb_M15.set` 或 `GoldFX_BasisArb_Conservative.set`
- 建议先 `InpSignalOnly=true` 观察
